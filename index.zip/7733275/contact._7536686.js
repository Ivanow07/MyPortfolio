<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Frexty</title>

  <!--
    - favicon
  -->
  <link rel="shortcut icon" href="../2031708/logo_ico_3080284_3342428_3670065_3539037.html" type="image/x-icon">

  <!--
    - custom css link
  -->
  <link rel="stylesheet" href="../1835097/style_1376363_262235_5308505_5505076.css">

  <!--
    - google font link
  -->
  <link rel="preconnect" href="../1704024/fonts.googleapis_com_4456470_5701679_7208997_6291524.html">
  <link rel="preconnect" href="../1704024/fonts.gstatic_com_7536732_4784205_1441826_7929892.html" crossorigin>
  <link href="../1507422/1245232_131076_7209072_1507408.css" rel="stylesheet">
</head>

<body>

  <!--
    - #MAIN
  -->

  <main>

    <!--
      - #SIDEBAR
    -->

    <aside class="sidebar" data-sidebar>

      <div class="sidebar-info">

        <figure class="avatar-box">
          <img src="../2031708/frexty_5636150_3276811_4128864_3801091.png" alt="Frexty" width="80">
        </figure>

        <div class="info-content">
          <h1 class="name" title="Frexty">Frexty</h1>

          <p class="title">Web & Discord Bot developer</p>
        </div>

        <button class="info_more-btn" data-sidebar-btn>
          <span>Show Contacts</span>

          <ion-icon name="chevron-down"></ion-icon>
        </button>

      </div>

      <div class="sidebar-info_more">

        <div class="separator"></div>

        <ul class="contacts-list">

          <li class="contact-item">

            <div class="icon-box">
              <ion-icon name="mail-outline"></ion-icon>
            </div>

            <div class="contact-info">
              <p class="contact-title">Email</p>

              <a href="../2031705/email-protection_4784239_7405677_7864321.html" class="contact-link"><span class="__cf_email__" data-cfemail="2a494544445e4b495e6a4c584f525e5304464546">[email&#160;protected]</span></a>
            </div>

        </ul>

        <div class="separator"></div>

        <ul class="social-list">

          <li class="social-item">
            <a href="discord://-/users/944536206320992256" class="social-link">
              <ion-icon name="logo-discord"></ion-icon>
            </a>
          </li>

          <li class="social-item">
            <a href="../1638481/youtube_655438_2555939_2228296.html" class="social-link">
              <ion-icon name="logo-youtube"></ion-icon>
            </a>
          </li>

          <li class="social-item">
            <a href="../1638481/twitch_4653171_5373980_5963900.html" class="social-link">
              <ion-icon name="logo-twitch"></ion-icon>
            </a>
          </li>

        </ul>

      </div>

    </aside>





    <!--
      - #main-content
    -->

    <div class="main-content">

      <!--
        - #NAVBAR
      -->

      <nav class="navbar">

        <ul class="navbar-list">

          <li class="navbar-item">
            <button class="navbar-link  active" data-nav-link>About</button>
          </li>

          <li class="navbar-item">
            <button class="navbar-link" data-nav-link>Resume</button>
          </li>

          <li class="navbar-item">
            <button class="navbar-link" data-nav-link>Portfolio</button>
          </li>

          <li class="navbar-item">
            <button class="navbar-link" data-nav-link>Blog</button>
          </li>

          <li class="navbar-item">
            <button class="navbar-link" data-nav-link>Contact</button>
          </li>

        </ul>

      </nav>





      <!--
        - #ABOUT
      -->

      <article class="about  active" data-page="about">

        <header>
          <h2 class="h2 article-title">About me</h2>
        </header>

        <section class="about-text">
          <p>
            I'm Creative desinger and Discord bot developer from Bulgaria.
            I enjoy
            turning complex problems into simple, beautiful and intuitive designs.
          </p>

          <p>
            My job is to build your website so that it is functional and user-friendly but at the same time attractive.
            Moreover, I
            add personal touch to your product and make sure that is eye-catching and easy to use. My aim is to bring
            across your
            message and identity in the most creative way. I created web design for many famous brand companies.
          </p>
        </section>


        <!--
          - service
        -->

        <section class="service">

          <h3 class="h3 service-title">What i'm doing</h3>

          <ul class="service-list">

            <li class="service-item">

              <div class="service-icon-box">
                <img src="../2031708/icon-design_5963792_8323178_1507432_7733356.svg
                " alt="design icon" width="40">
              </div>

              <div class="service-content-box">
                <h4 class="h4 service-item-title">Web design</h4>

                <p class="service-item-text">
                  The most modern and high-quality design made at a professional level.
                </p>
              </div>

            </li>

            <li class="service-item">

              <div class="service-icon-box">
                <img src="../2031708/icon-dev_7798873_6225959_5963851_6160424.svg" alt="Web development icon" width="40">
              </div>

              <div class="service-content-box">
                <h4 class="h4 service-item-title">Web development</h4>

                <p class="service-item-text">
                  High-quality development of sites at the professional level.
                </p>
              </div>

            </li>

          </ul>

        </section>

        <!--
          - testimonials modal
        -->

        <div class="modal-container" data-modal-container>

          <div class="overlay" data-overlay></div>

          <section class="testimonials-modal">

            <button class="modal-close-btn" data-modal-close-btn>
              <ion-icon name="close-outline"></ion-icon>
            </button>

            <div class="modal-img-wrapper">
              <figure class="modal-avatar-box">
                <img src="../2031708/avatar-1_7143428_524341_852075_6094949.png" alt="Ð§Ð¾Ð²ÐµÐº ÐµÐ´Ð½Ð¾" width="80" data-modal-img>
              </figure>

              <img src="../2031708/icon-quote_1245232_3539023_3473455_4128833.svg" alt="quote icon">
            </div>


          </section>

        </div>


        <!--
          - clients
        -->

        <section class="clients">

          <h3 class="h3 clients-title">Clients</h3>

          <ul class="clients-list has-scrollbar">

            <li class="clients-item">
              <a href="../1704024/brutalevolution_lol_5701666_7077942_3342425_5767250.html">
                <img src="../2031708/logo-1-color_2752521_589941_65579_5439506.png" alt="client logo">
              </a>
            </li>

            <li class="clients-item">
              <a href="../1704024/bloodline_lol_3997769_917596_983120_7274596.html">
                <img src="../2031708/logo-2-color_2752522_589941_65579_5439506.png" alt="client logo">
              </a>
            </li>

            <li class="clients-item">
              <a href="../1704024/varter_lol_7733344_6488156_5832798_5701695.html">
                <img src="../2031708/varter_4194338_2555934_2949235_2293788.png" alt="client logo">
              </a>
            </li>

            <li class="clients-item">
              <a href="../1704024/ttegav_shop_1572982_4259847_1179757_7798886.html">
                <img src="../2031708/ttegav_5308448_2752518_2097260_2490369.png" alt="client logo">
              </a>
            </li>

          </ul>

        </section>

      </article>





      <!--
        - #RESUME
      -->

      <article class="resume" data-page="resume">

        <header>
          <h2 class="h2 article-title">Resume</h2>
        </header>

        <section class="skill">

          <h3 class="h3 skills-title">My skills</h3>

          <ul class="skills-list content-card">

            <li class="skills-item">

              <div class="title-wrapper">
                <h5 class="h5">Web design</h5>
                <data value="80">80%</data>
              </div>

              <div class="skill-progress-bg">
                <div class="skill-progress-fill" style="width: 80%;"></div>
              </div>

            </li>

            <li class="skills-item">

              <div class="title-wrapper">
                <h5 class="h5">Java Script</h5>
                <data value="70">70%</data>
              </div>

              <div class="skill-progress-bg">
                <div class="skill-progress-fill" style="width: 70%;"></div>
              </div>

            </li>

            <li class="skills-item">

              <div class="title-wrapper">
                <h5 class="h5">WordPress</h5>
                <data value="50">50%</data>
              </div>

              <div class="skill-progress-bg">
                <div class="skill-progress-fill" style="width: 50%;"></div>
              </div>

            </li>

          </ul>

        </section>

      </article>





      <!--
        - #PORTFOLIO
      -->

      <article class="portfolio" data-page="portfolio">

        <header>
          <h2 class="h2 article-title">Portfolio</h2>
        </header>

        <section class="projects">

          <ul class="filter-list">

            <li class="filter-item">
              <button class="active" data-filter-btn>All</button>
            </li>

            <li class="filter-item">
              <button data-filter-btn>Web design</button>
            </li>

            <li class="filter-item">
              <button data-filter-btn>Applications</button>
            </li>

            <li class="filter-item">
              <button data-filter-btn>Servers</button>
            </li>

          </ul>

          <div class="filter-select-box">

            <button class="filter-select" data-select>

              <div class="select-value" data-selecct-value>Select category</div>

              <div class="select-icon">
                <ion-icon name="chevron-down"></ion-icon>
              </div>

            </button>

            <ul class="select-list">

              <li class="select-item">
                <button data-select-item>All</button>
              </li>

              <li class="select-item">
                <button data-select-item>Web design</button>
              </li>

              <li class="select-item">
                <button data-select-item>Applications</button>
              </li>

              <li class="select-item">
                <button data-select-item>Servers</button>
              </li>

            </ul>

          </div>

          <ul class="project-list">

            <li class="project-item  active" data-filter-item data-category="Servers">
              <a href="#">

                <figure class="project-img">
                  <div class="project-item-icon-box">
                    <ion-icon name="eye-outline"></ion-icon>
                  </div>

                  <img src="../2031708/logo-2-color_2752522_589941_65579_5439506.png" alt="finance" loading="lazy">
                </figure>

                <h3 class="project-title">BloodLineRP</h3>

                <p class="project-category">RolePlay Server</p>

              </a>
            </li>

            <li class="project-item  active" data-filter-item data-category="web development">
              <a href="#">

                <figure class="project-img">
                  <div class="project-item-icon-box">
                    <ion-icon name="eye-outline"></ion-icon>
                  </div>

                  <img src="../2031708/logo-1-color_2752521_589941_65579_5439506.png" alt="orizon" loading="lazy">
                </figure>

                <h3 class="project-title">BrutalEvolution</h3>

                <p class="project-category">RolePlay Server</p>

              </a>
            </li>

            <li class="project-item  active" data-filter-item data-category="web development">
              <a href="#">

                <figure class="project-img">
                  <div class="project-item-icon-box">
                    <ion-icon name="eye-outline"></ion-icon>
                  </div>

                  <img src="../2031708/varter_4194338_2555934_2949235_2293788.png" alt="orizon" loading="lazy">
                </figure>

                <h3 class="project-title">Varter</h3>

                <p class="project-category">Order Site</p>

              </a>
            </li>

            <li class="project-item  active" data-filter-item data-category="web development">
              <a href="#">

                <figure class="project-img">
                  <div class="project-item-icon-box">
                    <ion-icon name="eye-outline"></ion-icon>
                  </div>

                  <img src="../2031708/ttegav_5308448_2752518_2097260_2490369.png" alt="orizon" loading="lazy">
                </figure>

                <h3 class="project-title">Ttegav</h3>

                <p class="project-category">Order Site</p>

              </a>
            </li>

          </ul>

        </section>

      </article>





      <!--
        - #BLOG
      -->

      <article class="blog" data-page="blog">

        <header>
          <h2 class="h2 article-title">Blog</h2>
        </header>

        <section class="blog-posts">

          <ul class="blog-posts-list">

            <li class="blog-post-item">
              <a href="#">

                <figure class="blog-banner-box">
                  <img src="../2031708/welcome_30_4325428_4718686_4325429.png" alt="Welcome!" loading="lazy">
                </figure>

                <div class="blog-content">

                  <div class="blog-meta">
                    <p class="blog-category">Welcome</p>

                    <span class="dot"></span>

                    <time datetime="2022-02-23">May 30, 2024</time>
                  </div>

                  <h3 class="h3 blog-item-title">Welcome!</h3>

                  <p class="blog-text">
                    Welcome to my blog! Here you will find things that I worked, or am working on at the moment.
                  </p>

                </div>

              </a>
            </li>

          </ul>

        </section>

      </article>





      <!--
        - #CONTACT
      -->

      <article class="contact" data-page="contact">

        <header>
          <h2 class="h2 article-title">Contact</h2>
        </header>

        <section class="contact-form">

          <h3 class="h3 form-title">Contact Form</h3>

          <form action="#" class="form" data-form>

            <div class="input-wrapper">
              <input type="text" name="fullname" class="form-input" placeholder="Full name" required data-form-input>

              <input type="email" name="email" class="form-input" placeholder="Email address" required data-form-input>
            </div>

            <textarea name="message" class="form-input" placeholder="Your Message" required data-form-input></textarea>

            <button class="form-btn" type="submit" disabled data-form-btn>
              <ion-icon name="paper-plane"></ion-icon>
              <span>Send Message</span>
            </button>

          </form>

        </section>

      </article>

    </div>

  </main>






  <!--
    - custom js link
  -->
  <script data-cfasync="false" src="../2031705/email-decode.min_3407915_458846_7602299.js"></script><script src="../1245273/script_2097190_3539044_3538957_3932262.js"></script>
  <script src="../1245273/contact._4784142_1769476_1704044_1769480.js"></script>

  <!--
    - ionicon link
  -->
  <script type="module" src="../1769556/7995401_7798792_6160432_3342396.js"></script>
  <script nomodule src="../1769556/2555905_7798788_5439546_3473461.js"></script>

</body>

</html>